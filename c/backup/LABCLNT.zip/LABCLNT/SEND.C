#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "labclnt.h"
//#include <sqlext.h>

DWORD SendThreadProc(LPVOID pParm)
{
    int no;
    FILE *fp;
    //LPHOSTENT hp;
    //struct in_addr ip;
    //struct sockaddr_in addr;
    //DWORD *pa;
    char buf[2048], str[2048];
    char *p;
    char *q;
    //short port;
    //char server[260];
    char test[30];
    char seq[14];
	char result[22];
	char labno[20];
	char machine[12];
	int intseq;
	int dup;
	char fluid_type[2];

	SQLINTEGER Length = SQL_NTS;
	SQLHSTMT stmt;
	SQLCHAR SQL[200] = 
		"insert into LABO_INTERFACE (LAB_NUM, SEQ_NUM, CODE_K700, RESULT, MACH_CODE, FLUID_TYPE)values (?,?,?,?,?,?)";
	SQLCHAR SQL2[200];
		
//	SQLINTEGER SQLerr;
//	SQLSMALLINT SQLmsglen;
//	char pStatus[10], pMsg[101];

//	SQLCHAR OutConnStr[255];
//    SQLSMALLINT OutConnStrLen;

	SDWORD ldup;
	ldup = SQL_NTS;

_TRY_EXCEPTION_BLOCK_BEGIN()

    no = (int)pParm;
	strcpy(machine, g_Client[no].szProg);

	p = strrchr(g_Client[no].szFileName, '\\');

	p++;
	strcpy(labno, p);

	q = strtok(labno, "_.\0");
	strcpy(labno, q);
	labno[19] = '\0';

	fluid_type[0] = '\0';

	q = strrchr(p, '_');
	q++;
	fluid_type[0] = *q;
	fluid_type[1] = '\0';

/*	if (q != NULL) {
		q = strtok(NULL, "_.\0");
		fluid_type[0] = *q;
		fluid_type[1] = '\0';
	}*/

	p = strrchr(g_Client[no].szFileName, '\\');
	p = p + strlen(p) - g_nSeqDigit;
	strcpy(seq, p);

	intseq = atoi(seq);
//connection
/*
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &env);
    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		SQLGetDiagRec(SQL_HANDLE_ENV, env, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}

	ret = SQLSetEnvAttr(env, SQL_ATTR_ODBC_VERSION, (SQLPOINTER*) SQL_OV_ODBC3, 0);
    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		SQLGetDiagRec(SQL_HANDLE_ENV, env, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}

	ret = SQLAllocHandle(SQL_HANDLE_DBC, env, &dbc);
    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		SQLGetDiagRec(SQL_HANDLE_DBC, dbc, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}
	
	ret = SQLDriverConnect(
		dbc, 
        NULL, 
        (SQLCHAR*) g_szServer, 
		SQL_NTS,
        OutConnStr,
        255, 
        &OutConnStrLen,
        SQL_DRIVER_NOPROMPT );             

    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		SQLGetDiagRec(SQL_HANDLE_DBC, dbc, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}
*/

	while (1) {
		sprintf(SQL2, "select count(*) from LABO_DOWNHEAD where lab_num ='%s' and seq_num = '%d'", labno, intseq);
		
		ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt); 
		if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLPrepare(stmt, SQL2, SQL_NTS);
	    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}
	
		ret = SQLExecute(stmt);
		if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret=SQLBindCol(stmt,1,SQL_C_ULONG, &dup, sizeof(int), &ldup);
		if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLFetch(stmt); 
		if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret=SQLFreeHandle(SQL_HANDLE_STMT, stmt);
		if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		if (dup == 0)
			break;
		else
			intseq++;
	}
	sprintf(seq, "%d\0", intseq);

    fp = fopen(g_Client[no].szFileName, "rb");
    if (fp == NULL) {
        WriteLog("Can't open %s", g_Client[no].szFileName);
        if (g_dwErrorSleepTime != 0)
            Sleep(g_dwErrorSleepTime);
        g_Client[no].szFileName[0] = '\0';
        return 0;
    }

    while (1) {
        if (fgets(str, 256, fp) == NULL) break;
		
		p = strtok(str, "|\n\r\0");

		if (p != NULL) {
			strcpy(test, p);
			p = strtok(NULL, "|\n\r\0");
		} else {
			continue;
		}

		if (p != NULL) {
			strcpy(result, p);
		} else {
			continue;
		}

		ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt); 
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

// Bind Parameters
		ret = SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			labno, sizeof(labno), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLBindParameter(stmt, 2, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			seq, sizeof(seq), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLBindParameter(stmt, 3, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			test, sizeof(test), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLBindParameter(stmt, 4, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			result, sizeof(result), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLBindParameter(stmt, 5, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			machine, sizeof(machine), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		ret = SQLBindParameter(stmt, 6, SQL_PARAM_INPUT,
			SQL_C_CHAR, SQL_CHAR, 0, 0,
			fluid_type, sizeof(fluid_type), &Length);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}

		WriteLog("labno=%s seq=%s test=%s result=%s machine=%s fluid_type=%s", labno, seq, test, result, machine, fluid_type);

//Prepare SQL
		ret = SQLPrepare(stmt, SQL, SQL_NTS);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}
// Execute statement with parameters
		ret = SQLExecute(stmt);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}
		ret=SQLFreeHandle(SQL_HANDLE_STMT, stmt);
        if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
			SQLGetDiagRec(SQL_HANDLE_STMT, stmt, 1,
				pStatus,&SQLerr,pMsg,100,&SQLmsglen);
			WriteLog("%s:%s", pStatus, pMsg);
			dbconnect();
			continue;
		}
	}

//Disconnect
/*
    ret=SQLDisconnect(dbc);
    if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		ret = SQLGetDiagRec(SQL_HANDLE_DBC, dbc, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}

    ret=SQLFreeHandle(SQL_HANDLE_DBC, dbc);
	if(ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
		ret = SQLGetDiagRec(SQL_HANDLE_DBC, dbc, 1,
			pStatus,&SQLerr,pMsg,100,&SQLmsglen);
		WriteLog("%s:%s", pStatus, pMsg);
	}
*/

    fclose(fp);
    if (g_Client[no].bCopyTest != 0 && g_Client[no].szTestDir[0] != '\0') {
        char drive[_MAX_DRIVE];
        char dir[_MAX_DIR];
        char fname[_MAX_FNAME];
        char ext[_MAX_EXT];

        _splitpath(g_Client[no].szFileName, drive, dir, fname, ext);
        _makepath(buf, "", g_Client[no].szTestDir, fname, ext);
        CopyFile(g_Client[no].szFileName, buf, FALSE);
        WriteLog("CopyFile %s to %s", g_Client[no].szFileName, buf);
    }
    if (g_bBackup) {
        time_t t;
        struct tm *tp;
        char szToday[200];

        time(&t);
        tp = localtime(&t);
        strftime(szToday, 200, "%y%m%d", tp);
        sprintf(buf, "%sBACKUP\\%s", g_szRootPath, szToday);
        CreateDirectory(buf, NULL);
        strftime(str, 200, "%H%M%S", tp);
        if (g_Client[no].nSeq == 2)
            sprintf(buf, "%sBACKUP\\%s\\%s.%s.%s.txt", g_szRootPath, szToday,
                                         str, g_Client[no].szProg,
                                         g_Client[no].szNo);
        else
            sprintf(buf, "%sBACKUP\\%s\\%s.%s.%04d-%04d.txt", g_szRootPath, szToday,
                                         str, g_Client[no].szProg,
                                         g_Client[no].nSector, g_Client[no].nCup);

        MoveFile(g_Client[no].szFileName, buf);
        WriteLog("MoveFile %s to %s", g_Client[no].szFileName, buf);
    }
	WriteLog("Delete FIle: %s", g_Client[no].szFileName);
    unlink(g_Client[no].szFileName);
    g_Client[no].bCheck = FALSE;
    g_Client[no].szFileName[0] = '\0';
	
_TRY_EXCEPTION_BLOCK_END(1)

    return 1;
}

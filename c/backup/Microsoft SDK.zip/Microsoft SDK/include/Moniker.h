//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1999.
//
//  File:       moniker.h
//
//----------------------------------------------------------------------------

#if _MSC_VER > 1000
#pragma once
#endif

#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include objbase.h instead of moniker.h")
#endif /* !RC_INVOKED */

#include <objbase.h>


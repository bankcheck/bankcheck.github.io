//  Copyright (c) Microsoft Corporation. All rights reserved.
#define __MTxSpm_LIBRARY_DEFINED__
#include "comsvcs.h"

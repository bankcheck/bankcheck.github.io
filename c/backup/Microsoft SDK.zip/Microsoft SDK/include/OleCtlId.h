/*****************************************************************************\
*                                                                             *
* olectlid.h    Master definition of GUIDs for OLE Controls                   *
*                                                                             *
*               OLE Version 2.0                                               *
*                                                                             *
*               Copyright (c) 1992-1999, Microsoft Corp. All rights reserved. *
*                                                                             *
\*****************************************************************************/

#if _MSC_VER > 1000
#pragma once
#endif

#pragma message("WARNING: your code should #include olectl.h instead of olectlid.h")
#include <olectl.h>

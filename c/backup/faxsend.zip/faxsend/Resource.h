//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FAXSEND.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FAXSEND_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_STATIC_STATE                1005
#define IDC_STATIC_CIS                  1006
#define IDC_FAX_DATA                    1007
#define IDC_SPEED                       1010
#define IDC_STATIC_SPEED                1011
#define IDC_STATIC_REMOTE               1014
#define IDC_TIME                        1019
#define IDC_PAGE                        1020
#define IDC_STATIC_OP                   1022
#define IDC_STATIC_FAX_DATA             1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

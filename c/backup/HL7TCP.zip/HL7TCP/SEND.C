#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "hl7tcp.h"

//DWORD SendThreadProc(LPVOID pParm)
int Send(void)
{
    FILE *fp;
    char buf[2048], str[2048];
    char *p;

    WriteLog("FileName: %s", g_Client.szFileName);

    fp = fopen(g_Client.szFileName, "rb");
    if (fp == NULL) {
        WriteLog("Can't open %s", g_Client.szFileName);
        if (g_dwErrorSleepTime != 0)
            Sleep(g_dwErrorSleepTime);
        g_Client.szFileName[0] = '\0';
        return 0;
    }

    while (1) {
		if (fgets(str, 256, fp) == NULL) break;
        
		p = strtok(str, "\n\r");
		
		if (p == NULL) break;

        sprintf(buf, "%s\r", p);
		PutLine(buf);
	}


	while (1) {
		if (g_bQuit || WaitForSingleObject(g_hServerStopEvent, g_dwSleepTime) == WAIT_OBJECT_0)
			break;

		if (GetLine(buf, 1024) == 0) {
			WriteLog("Can't get response");
			disconnect();
			if (g_dwErrorSleepTime != 0)
				Sleep(g_dwErrorSleepTime);

			g_Client.szFileName[0] = '\0';
			fclose(fp);
			break;
		} else {
		}

		p = strtok(buf, "|");
        
		if (memcmp(buf, "MSA", 3) == 0) {
			if (p != NULL)
				p = strtok(NULL, "|");
			else
				WriteLog("Invalid acknoledgement message");

			if (strcmp(p, "AA") == 0)
				WriteLog("ACCEPTED");
			else
				WriteLog("Message error: %s", p);
			break;
	    }
	}

	fclose(fp);

	if (g_bBackup) {
        time_t t;
	    struct tm *tp;
        char szToday[200];

		time(&t);
		tp = localtime(&t);
	    strftime(szToday, 200, "%y%m%d", tp);
        sprintf(buf, "%sBACKUP\\%s", g_szRootPath, szToday);
	    CreateDirectory(buf, NULL);
        strftime(str, 200, "%H%M%S", tp);
        
		sprintf(buf, "%sBACKUP\\%s\\%s.txt", g_szRootPath, szToday,
                                         str);
	    MoveFile(g_Client.szFileName, buf);
    }

    fclose(fp);
	unlink(g_Client.szFileName);
    g_Client.szFileName[0] = '\0';

	return 1;
}

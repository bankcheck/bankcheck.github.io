#include <stdio.h>
#include <string.h>
#include "hl7tcp.h"

int PutLine(char *buf)
{
    int n;
    BOOL b;

	if (!g_bConnect)
		g_bConnect = tcpconnect();

    b = g_Client.bCheck;
    g_Client.bCheck = FALSE;
    g_Client.tick = GetTickCount();
    g_Client.bCheck = b;
    
	if (g_Client.s == SOCKET_ERROR) return 0;
    
	n = send(g_Client.s, buf, strlen(buf), 0);
    
	if (n == 0 || n == SOCKET_ERROR) {
		WriteLog("Error sending message: %s", buf);
		
		if (g_dwErrorSleepTime != 0)
			Sleep(g_dwErrorSleepTime);

		return 0;
	} else {
		WriteLog("SEND: %s", buf);
		return 1;
	}
}

int GetLine(char *buf, int bufsize)
{
    int n;
    char ch;
    int i;
    BOOL b;

_TRY_EXCEPTION_BLOCK_BEGIN()
	if (!g_bConnect)
		g_bConnect = tcpconnect();

    if (g_Client.s == SOCKET_ERROR) return 0;
    i = 0;
    buf[0] = '\0';
    while (1) {
        b = g_Client.bCheck;
        g_Client.bCheck = FALSE;
        g_Client.tick = GetTickCount();
        g_Client.bCheck = b;
        n = recv(g_Client.s, &ch, 1, 0);
        if (n == 0 || n == SOCKET_ERROR)
	    return 0;

		buf[i++] = ch;
/*
		if (ch == '\n' && buf[i-2] == '\r') {
			buf[i-2] = '\0';
			break;
		}
*/
		if (ch == '\r') {
			buf[i-1] = '\0';
			WriteLog("RECV: %s", buf);
			break;
		}

		if (i >= bufsize) {
			buf[i] = '\0';
			WriteLog("RECV: %s", buf);
            break;
		}
    }

_TRY_EXCEPTION_BLOCK_END(1)

    return i;
}

int AddBslash(char *s)
{
    int len;

_TRY_EXCEPTION_BLOCK_BEGIN()

    len = strlen(s);
    if (len == 0) return 0;
    if (s[len-1] == '\\' || s[len-1] == '/') return 0;
    s[len++] = '\\';
    s[len] = '\0';

_TRY_EXCEPTION_BLOCK_END(1)

    return 1;
}

int tcpconnect(void){
    LPHOSTENT hp;
    struct in_addr ip;
    struct sockaddr_in addr;
    DWORD *pa;
    short port;
    char server[260];

	g_Client.bCheck = FALSE;
    g_Client.s = SOCKET_ERROR;

    WriteLog("Connecting..");
	strcpy(server, g_szServer);
	port = g_nPort;
    hp = gethostbyname(server);

	if (hp == NULL) {
        ip.s_addr = inet_addr(server);

		if (ip.s_addr == INADDR_NONE) {
		    WriteLog("Can't get IP for %s", server);
			
			if (g_dwErrorSleepTime != 0)
				Sleep(g_dwErrorSleepTime);

			g_Client.szFileName[0] = '\0';
			return 0;
		}
	}
    else {
		pa = (DWORD *)hp->h_addr_list[0];
		ip.s_addr = *pa;
    }

    g_Client.s = socket(AF_INET, SOCK_STREAM, 0);
	if (g_Client.s == SOCKET_ERROR) {
        WriteLog("Can't open TCP socket");

		if (g_dwErrorSleepTime != 0)
			Sleep(g_dwErrorSleepTime);
			
		g_Client.szFileName[0] = '\0';
	    return 0;
    }

	g_Client.tick = GetTickCount();
    g_Client.bCheck = TRUE;

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip.s_addr;
    addr.sin_port = htons(port);

	if (connect(g_Client.s, (LPSOCKADDR)&addr, sizeof(addr)) != 0) {
	    WriteLog("Can't connect to %s:%d", server, port);
        g_Client.bCheck = FALSE;

		if (g_dwErrorSleepTime != 0)
	        Sleep(g_dwErrorSleepTime);

        g_Client.szFileName[0] = '\0';
		return 0;
    }
	
	WriteLog("Connected to %s:%d", server, port);
	return 1;
}

void disconnect(void){
	g_Client.bCheck = FALSE;
	closesocket(g_Client.s);
	g_Client.s = SOCKET_ERROR;
	WriteLog("Disconnected");
	g_bConnect = FALSE;
}

void stayAlive(void){
	PutLine("ping\n");
}
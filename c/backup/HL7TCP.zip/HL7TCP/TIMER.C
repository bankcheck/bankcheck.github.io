#include "hl7tcp.h"

DWORD TimerThreadProc(LPVOID pParm)
{
    DWORD now, len, tick;
//     SOCKET s;
//    int i;

_TRY_EXCEPTION_BLOCK_BEGIN()

    g_bTimerQuit = FALSE;
    while (1) {
        if (g_bQuit || WaitForSingleObject(g_hServerStopEvent, 3000) == WAIT_OBJECT_0)
            break;
            
		if (g_Client.bCheck == FALSE)
			continue;
            
        now = GetTickCount();
        
		if (g_Client.s != SOCKET_ERROR) {
			tick = g_Client.tick;
            
			if (now >= tick)
				len = now - tick;
            else
				len = now;

            if (len > g_dwMaxIdle) {
				stayAlive();
            }
        }
    }

	g_bTimerQuit = TRUE;
    WriteLog("TimerThread Exit");
    ExitThread(0);

_TRY_EXCEPTION_BLOCK_END(1)

    return 0;
}


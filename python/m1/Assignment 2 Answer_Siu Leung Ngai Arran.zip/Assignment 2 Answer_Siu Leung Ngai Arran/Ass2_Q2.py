#Get user input, convert to upper case,
# and store in string variable sentence
sentence = input("Input a sentence: ").upper()

#Split the word in the sentence and store in wordList
wordList = sentence.split()

#Empty dictionary to store final result
wordDict = {}

#For each word in wordList,
# if the word does not appear in the dictionary,
# add the word to the dictionary with value = 1
# If the word is in the dictionary, increment its value
for word in wordList:
    if word in wordDict:
        wordDict[word] += 1
    else:
        wordDict[word] = 1

#Print final result
print("---------Result---------")    
print(wordDict)


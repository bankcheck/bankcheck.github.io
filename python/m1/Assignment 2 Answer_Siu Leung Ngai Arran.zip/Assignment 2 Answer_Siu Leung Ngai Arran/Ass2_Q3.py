#Import random library for secret number
import random

#Print rules
print('-----------------Rules-----------------')
print('1. Guess the secret number between 1 and 25.')
print('2. Input "Secret" to show the secret number if you want.')
print('---------------------------------------------')

#Pick a secret number from 1 to 25
secret = random.randrange(1, 26)

#Get initial user guess
userInput = input("Guessing number from you>>> ")

#Keep guessing until user give up by typing secret
while (userInput.lower() != "secret"):
    
    if secret > int(userInput):
#Print message if the secret number is larger      
        print("Secret number should be larger")
    elif secret < int(userInput):
#Print message if the secret number is smaller          
        print("Secret number should be smaller")
    else:
#Print message when user got the secret number
# and break the loop     
        print("Nice! Secret number =", secret)
        break
    
#Ask user to enter the next guess    
    userInput = input("Guessing number from you>>> ")
else:
#Print the secret number when user give up    
    print("Secret number is", secret)

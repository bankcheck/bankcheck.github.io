#Empty list to store input later
numberList = []

#String variable item to store input
item = input('Enter the number (Input "End" to end the input): ')

#Variable to calculate sum
sum = 0

#While loop to append item into the numberList
# and calculate the sum until user input end
while (item.lower() != "end"):
    numberList.append(float(item))
    sum += float(item)
    item = input('Enter the number (Input "End" to end the input): ')

#Print numberList
print("-------Input List-------")
print(numberList)
print("------------------------")

#Print max
print("Maximum value in the list: ", max(numberList))

#Calculate and print average
print("Average value in the list: ", sum/len(numberList))
    



num1 = 1
num2 = 2
print(num1 + num2) # Output: 3

str1 = "Nice to "
str2 = "meet you"
print(str1+str2) # Output : Nice to meet you


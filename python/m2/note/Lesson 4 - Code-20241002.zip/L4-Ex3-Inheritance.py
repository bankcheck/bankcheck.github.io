class Transportation:  
    def addspeed(self):  
        print("Adding Speed")  
#Child class Plane inherits the base class Transportation  	
class Plane(Transportation):  
    def fly(self):  
        print("flying in the sky")  	
p = Plane()  
p.addspeed()  
p.fly()  


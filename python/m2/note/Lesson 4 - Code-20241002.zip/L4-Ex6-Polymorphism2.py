class Poly:
    def show(self, a=None, b=None):
        print(a,b)
		
p = Poly()
p.show()
p.show(2)
p.show(2,4)


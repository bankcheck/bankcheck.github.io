import numpy as np

arr = np.array([[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15]])

print('Last row and last column: ', arr[-1, -1])
print('Second last row and last column: ', arr[-2, -1])


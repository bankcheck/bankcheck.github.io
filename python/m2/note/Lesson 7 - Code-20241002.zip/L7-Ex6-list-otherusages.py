sampleList = ["Peter", "Paul", "Mary"]
sampleList.insert(6,"Wendy")
sampleList.append("Fred")
sampleList.remove("Paul")
sampleList.pop(0)
print(sampleList)

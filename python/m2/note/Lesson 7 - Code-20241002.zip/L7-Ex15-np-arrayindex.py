import numpy as np

arr = np.array([1, 2, 3, 4])

print(arr[0])
print(arr[1])


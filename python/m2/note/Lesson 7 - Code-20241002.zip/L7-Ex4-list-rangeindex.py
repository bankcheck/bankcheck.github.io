sampleList = ["0Peter", "1Paul", "2Mary","3June", "4Larry", "5May","6Yan", "7Sean"]
print(sampleList[2:6])
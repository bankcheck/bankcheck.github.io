sampleList = ["Peter", "Paul", "Mary"]
print(len(sampleList))
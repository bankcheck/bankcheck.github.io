import numpy as np

arr = np.array(['ABC', 'DEF', 'GHI'])

print(arr)


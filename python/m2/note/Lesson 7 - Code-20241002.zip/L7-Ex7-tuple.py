sampleTuple = ("Peter", "Paul", "Mary")
print(sampleTuple[0])

sampleSet = {"Peter", "Paul", "Mary"}
print(sampleSet)
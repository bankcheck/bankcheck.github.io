sampleDict = {"Peter":20, "Paul":25, "Mary":30}
sampleDict["Joe"] = 35
sampleDict["Peter"] = 25
sampleDict.pop("Paul") 
print(sampleDict)

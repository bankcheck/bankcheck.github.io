sampleList = ["Peter", "Paul", "Mary"]
print(sampleList[-1])
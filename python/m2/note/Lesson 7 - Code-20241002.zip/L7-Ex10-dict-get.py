sampleDict = {"Peter":20, "Paul":25, "Mary":30}
print(sampleDict.get("Peter"))

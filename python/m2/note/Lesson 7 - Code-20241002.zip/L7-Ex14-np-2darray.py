import numpy as np

arr = np.array([['Col1', 'Col2', 'Col3'], [4, 5, 6]])

print(arr)

sampleList = ["Peter", "Paul", "Mary"]
if "Mary" in sampleList:
	print("Mary is on list")
for x in sampleList:
	print(x)

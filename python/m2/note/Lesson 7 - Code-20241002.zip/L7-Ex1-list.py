sampleList = ["Peter", "Paul", "Mary"]
print(sampleList)
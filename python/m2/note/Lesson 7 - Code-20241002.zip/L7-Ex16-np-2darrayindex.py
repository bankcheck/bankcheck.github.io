import numpy as np

arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])

print('1st row and 1st column: ', arr[0, 0])
print('1st row and 3rd column: ', arr[0, 2])
print('2nd row and 1st column: ', arr[1, 0])
print('2nd row and 5th column: ', arr[1, 4])


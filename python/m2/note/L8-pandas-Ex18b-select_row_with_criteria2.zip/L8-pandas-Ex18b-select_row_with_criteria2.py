import pandas as pd

titanic = pd.read_csv("titanic.csv")

for i in range(len(titanic)):
    titanic.at[i, "Sex"] = titanic.at[i, "Sex"].upper()

female_pass = titanic[titanic["Sex"] == "FEMALE"]

print(female_pass.head(10))
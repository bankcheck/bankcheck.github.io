import shutil
import os

if not os.path.exists("C:/Python/test1.txt"):
    shutil.copyfile("C:/Python/test.txt", "C:/Python/test1.txt")
else:
    print("Already exists")
    

import shutil
import datetime

today = datetime.date.today()

today_str = today.strftime('%Y-%m-%d')

print(today_str)

shutil.move("test.txt", "test_"+today_str+".txt")

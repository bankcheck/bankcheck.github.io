


import shutil
shutil.move("test1.txt", "../Temp/test1.txt")

import os
os.rmdir("testing-mkdir")

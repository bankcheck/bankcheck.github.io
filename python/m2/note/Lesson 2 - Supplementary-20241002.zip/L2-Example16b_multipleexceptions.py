try:
    a = 10 / 0
    print(a)
    
except (ZeroDivisionError, KeyError):
    print ("Error!!!")

'''
try:
    a = 10 / 0
    print(a)
    
except ZeroDivisionError:
    print ("ZeroDivisionError!!!")

except KeyError:
    print ("KeyError!!!")
    
'''

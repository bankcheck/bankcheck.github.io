import shutil
shutil.move("C:/Python/test/test.txt", "C:/Python/test.txt")

fob = open("C:/Python/test.txt", "r")
print(fob.readline())
print(fob.readline())
fob.close()

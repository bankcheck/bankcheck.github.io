fob = open("C:/Python/test.txt", "r")
for line in fob:
    print(line)
fob.close()

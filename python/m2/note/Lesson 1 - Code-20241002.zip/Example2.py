fob = open("C:/Python/test_write.txt", "w")
fob.write("Testing1!")
fob.close()

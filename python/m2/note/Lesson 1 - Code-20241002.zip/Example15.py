fob = open("C:/Python/test_append.txt", "a")
fob.write("I Love Python!")
fob.close()

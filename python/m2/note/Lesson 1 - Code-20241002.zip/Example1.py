fob = open("C:/Python/test.txt", "r+")

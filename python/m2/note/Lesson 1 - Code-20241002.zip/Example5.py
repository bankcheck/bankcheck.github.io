fob = open("C:/Python/test.txt", "r")
print(fob.read())
fob.close()

import os
os.remove("C:/Python/test1.txt")

fob = open("C:/Python/test_write.txt", "w")
fob.write("Enjoy Learning Python!")
fob.write("Sure!")
fob.close()

fob = open("C:/Python/test.txt", "r")
print(fob.readline(3))
fob.close()

fob = open("C:/Python/test.txt", "r")
print(fob.read(4))
fob.close()

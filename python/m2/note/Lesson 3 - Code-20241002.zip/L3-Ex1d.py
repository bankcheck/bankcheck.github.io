class Dog:

    def __init__(self):
        pass


golden = Dog()
print(golden) #print to view the info of object

class Dog:

    def __init__(self):
        pass


golden = Dog()

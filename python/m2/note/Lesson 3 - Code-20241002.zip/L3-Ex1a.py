class Dog:

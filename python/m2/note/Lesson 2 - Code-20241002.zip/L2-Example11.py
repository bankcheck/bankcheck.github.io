a = ['a', 'b', 'c']
print (a[3])

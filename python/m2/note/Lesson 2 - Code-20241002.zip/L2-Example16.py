try:
    a = 10 / 0
    print(a)
    
except ZeroDivisionError:
    print ("Divided by Zero!!!")

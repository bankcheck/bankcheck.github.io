print(float("string"))

import os
out = os.path.dirname("C:/Python/test_write.txt")
print(out)

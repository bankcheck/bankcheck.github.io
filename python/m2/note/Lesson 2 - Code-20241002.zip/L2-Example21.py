x = 2
print("This is the before value of x: ", x)
x = x + 10
print("This is the after value of x: ", x)

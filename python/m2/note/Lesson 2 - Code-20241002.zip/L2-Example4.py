import os
dirname = os.path.dirname(__file__)
filename = dirname + r"\test\test.txt"
print(__file__)
print(dirname)
print(filename)

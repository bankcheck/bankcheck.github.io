a = 10
b = "string"
c = a + b

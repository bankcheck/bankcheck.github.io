import shutil
print("Start – copy files")
shutil.copyfile("C:/Python/test.txt", "C:/Python/test1.txt")
print("End – copy files")

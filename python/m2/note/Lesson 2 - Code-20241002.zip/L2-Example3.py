import os
out = os.path.getsize("C:/Python/test_write.txt")
print(out)

import os
dirname = os.path.dirname(__file__)
filename = os.path.join(dirname, r"test\test.txt")
print(__file__)
print(dirname)
print(filename)

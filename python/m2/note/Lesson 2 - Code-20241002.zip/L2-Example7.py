def recursion():
    return recursion()

recursion()

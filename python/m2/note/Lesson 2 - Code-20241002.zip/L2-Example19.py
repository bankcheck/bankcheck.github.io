if int(input()) < 0:
    raise Exception("Input non-negative number, please.")

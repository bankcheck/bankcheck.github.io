import glob
for filename in glob.glob("C:/Python/*"):
    print(filename)

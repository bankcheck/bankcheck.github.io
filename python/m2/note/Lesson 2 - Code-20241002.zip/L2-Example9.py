import math
print(math.exp(999))

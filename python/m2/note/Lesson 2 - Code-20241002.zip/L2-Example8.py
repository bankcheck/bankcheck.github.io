result = 100 / 0
print(result)

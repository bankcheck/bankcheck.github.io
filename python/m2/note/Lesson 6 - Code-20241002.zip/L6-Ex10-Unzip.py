import shutil

shutil.unpack_archive("ZIP FILE (WITH PATH)","EXTRACT TO (FOLDER)")

import shutil

shutil.make_archive("OUTFILE (WITH PATH)","zip", "DESTINATION PATH","FILE / FOLDER NAME")

# Input
name = input("Enter Student Name: ")
age = input("Enter Age: ")
phone = input("Enter Phone Number: ")

# Display
print("\n")
print("Printing Student Details")
print("Name", "Age", "Phone")
print(name, age, phone)
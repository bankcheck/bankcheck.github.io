phone = int(input("Enter your phone number: "))
print("Your Phone Number is " + str(phone))


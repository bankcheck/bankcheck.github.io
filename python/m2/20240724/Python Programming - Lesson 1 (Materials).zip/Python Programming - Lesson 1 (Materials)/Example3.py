with open("C:/Python/test_write.txt", "w") as fob:
    fob.write("Testing2!")

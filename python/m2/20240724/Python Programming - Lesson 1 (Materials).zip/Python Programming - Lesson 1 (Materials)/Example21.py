import shutil
shutil.copyfile("C:/Python/test.txt", "C:/Python/test1.txt")

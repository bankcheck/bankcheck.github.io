import os
os.rename("C:/Python/test.txt", "C:/Python/test/test.txt")

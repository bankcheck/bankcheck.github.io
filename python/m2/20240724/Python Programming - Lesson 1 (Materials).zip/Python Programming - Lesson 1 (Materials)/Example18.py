import os
os.rename("C:/Python/test1.txt", "C:/Python/test.txt")

fob = open("C:/Python/test.txt", "r")
print(fob.readlines())
fob.close()

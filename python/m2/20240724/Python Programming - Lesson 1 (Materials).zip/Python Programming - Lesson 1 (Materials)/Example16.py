words = ["\nGood", "\nGreat", "\nNice"]
fob = open("C:/Python/test_append.txt", "a")
fob.writelines(words)
fob.close()

import os
os.rename("test.txt", "test1.txt")
